#!/bin/bash

i=5
while test $i != 0
do
	echo "$i"

	i=`expr $i - 1`
done
